try:
    from localsettings import *
except ImportError:
    pass
